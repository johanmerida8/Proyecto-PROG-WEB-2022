<?php

namespace App\Http\Controllers;
use App\Models\Menu;
use App\Models\Pedido;
use App\Models\Cliente;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index() 
    {
        return view('home.index', ["menulist" => Menu::all()]);
    }

    public function pedido($id)
    {
        $menudet = Menu::where(["id" => $id])->first();
        return view("home.pedido", ["clientes" => Cliente::all(), "menudetail" => $menudet]);
    }

    public function guardarPedido(Request $request, $id) {
        Pedido::create([
            "menu" => $id,
            "cliente" => $request->cliente,
            "quantity" => $request->quantity,
            "totalprice" => $request->totalprice,
        ]);
        return redirect()->to('/');
    }
    
}
