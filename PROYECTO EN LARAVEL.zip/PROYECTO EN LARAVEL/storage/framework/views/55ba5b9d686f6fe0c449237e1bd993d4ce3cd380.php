
<?php $__env->startSection("title", "Menu List"); ?>
<?php $__env->startSection("content"); ?>
<a href="/newmenu" class="btn btn-primary">New menu</a>
<table class="table table-primary">
    <br>
    <thead>
        <tr>
            <th>
                Cliente
            </th>
            <th>
                Menu
            </th>
            <!--<th>
                Description
            </th>-->
            <th>
                Quantity
            </th>
            <th>
                Price
            </th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
            <?php echo e($pedido->firstname); ?> <?php echo e($pedido->lastname); ?>

            </td>
            <td>
                <?php echo e($pedido->name); ?>

            </td>
            <td>
                <?php echo e($pedido->quantity); ?>

            </td>
            <td>
                <?php echo e($pedido->totalprice); ?>

            </td>
            
            <td>
               
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("templates.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NITRO\Desktop\cafe2\resources\views/pedidos/list.blade.php ENDPATH**/ ?>