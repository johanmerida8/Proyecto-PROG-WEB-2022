<?php $__env->startSection('content'); ?>
<h2>Detalle de pedido</h2>
<form action="/guardarpedido" method="post">
    <?php echo csrf_field(); ?>
    <div>
      <select id="cliente" name="cliente">
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value=<?php echo e($cliente->id); ?>><?php echo e($cliente->firstname); ?> <?php echo e($cliente->lastname); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div>
        Cantidad:
        <input type="text" name="quantity" class="form-control">
    </div>
    <div>
        Total:
        <input type="text" name="totalprice" class="form-control">
    </div>
    <div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="/" class="btn btn-primary">Cancelar</a>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bladimiro/Documents/pruebas/johan/student-practicas/cafe/resources/views/home/pedido.blade.php ENDPATH**/ ?>