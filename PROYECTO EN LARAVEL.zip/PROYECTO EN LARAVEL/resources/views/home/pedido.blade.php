@extends('layouts.app-master')

@section('content')
<h2>Detalle de pedido</h2>
{{$menudetail->name}}

<form action="{{url('guardarpedido/'.$menudetail->id)}}" method="post">
    @csrf
    <div>
      <input type="hidden" name="menu" value="{{$menudetail->id}}" />
      <select id="cliente" name="cliente">
        @foreach ($clientes as $cliente)
          <option value={{$cliente->id}}>{{$cliente->firstname}} {{$cliente->lastname}}</option>
        @endforeach
      </select>
    </div>
    <div>
        Cantidad:
        <input type="text" name="quantity" class="form-control">
    </div>
    <div>
        Total:
        <input type="text" name="totalprice" class="form-control">
    </div>
    <div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="/" class="btn btn-primary">Cancelar</a>
    </div>
</form>
@endsection