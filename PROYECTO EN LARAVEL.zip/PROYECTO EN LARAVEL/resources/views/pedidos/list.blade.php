@extends("templates.main")
@section("title", "Menu List")
@section("content")
<a href="/newmenu" class="btn btn-primary">New menu</a>
<table class="table table-primary">
    <br>
    <thead>
        <tr>
            <th>
                Cliente
            </th>
            <th>
                Menu
            </th>
            <!--<th>
                Description
            </th>-->
            <th>
                Quantity
            </th>
            <th>
                Price
            </th>
            
        </tr>
    </thead>
    <tbody>
        @foreach ($pedidos as $pedido)
        <tr>
            <td>
            {{ $pedido->firstname }} {{ $pedido->lastname }}
            </td>
            <td>
                {{ $pedido->name }}
            </td>
            <td>
                {{ $pedido->quantity }}
            </td>
            <td>
                {{ $pedido->totalprice }}
            </td>
            
            <td>
               
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@stop